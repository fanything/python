from distutils.core import setup

setup(
	name	= 'nester',
	version = '1.3.0',
	py_modules = ['nester'],
	author	= 'fmx',
	author_email = 'fmx@125.com',
	url	= 'http://fmx.com',
	description = 'a simple printer'
)